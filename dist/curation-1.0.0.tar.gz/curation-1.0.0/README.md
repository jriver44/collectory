# Curation

** Curation** is a lightweight, terminal-based collection based tracker that will evolve into a smart database tool for hobbyists. Designed for flexibility and evetual AI integration, it supports simple collection management for cigars, vinyl, trading cards, and more. 

---

## Features

- **CRUD CLI**: Add, remove, list, edit category, filter, search
- **UUIDs**: Every item gets a unique ID
- **Quantity Tracking**: Increment or decrement per item
- **Autosave & Backups**: Daemon thread writes every *N* seconds + rotating timestamped backups
- **Table view**: Neat ASCII grid of your collection
- **Summary**: Category & time-bucket distributions
- **ANSI color**: Colored prompts, errors (red), successes (green), headers (cyan)
- **Test suite**: 100% coverage of core logic

---

** Installation
```bash
git clone https://github.com/jriver44/collectory.git
cd collectory
python3 -m venv .venv   # optional
source .venv/bin/activate
pip install .

$ curation --help
Usage: curation [OPTIONS]

Options:
    --help  Show this message and exit


