import errno
import json
import os
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from colorama import init, Fore, Style
from tabulate import tabulate
from collectory.analysis import ( 
    increment_quantity, 
    create_new_item, 
    remove_item, 
    filter_by_category, 
    search_by_keyword,
    get_category_distribution,
    get_time_distribution
)
from collectory import config

init(autoreset=True)
_save_lock = threading.Lock()

def main():
    running = True

    file_name = prompt_nonempty("Enter name to load: ")
    path = config.collection_path(file_name)
    items = load_items(path)
    
    t = threading.Thread(
        target=autosave_loop,
        args=(file_name, items),
        daemon=True
    )
    t.start()
    try:
        while running:
            display_menu()
            choice = prompt_nonempty("Select an option (1-9)]: ")
            if choice == "1":
                name = prompt_nonempty("Enter new item name: ")
                category = prompt_nonempty("Enter item category: ")
                quantity = prompt_positive_int("Quantity to add: ")
            
                matches = [e for e in items 
                       if e["name"].lower() == name.lower() and e["category"].lower() == category.lower()]
                if matches:
                    entry = matches[0]
                    increment_quantity(entry, quantity)
                    print_success(f"{quantity} added to '{name}'. New total: {entry['quantity']}")
                else:
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    create_new_item(name, items, category, quantity, timestamp)
                    print_success(f"Created new item '{name}' x {quantity}.")
            elif choice == "2":
                target = prompt_nonempty( "Enter name of item to remove: ")
                quantity = prompt_positive_int("Quantity to remove: ")
                success = remove_item(items, quantity, target)
                confirm_action(
                    success,
                    success_message = f"Removed {quantity} x {target}",
                    error_message = f"Couldn't remove {target}"
                )
            elif choice == "3":
                success = edit_category(items)
                confirm_action(
                    success,
                    success_message = f"{target}'s category changed successfully.",
                    error_message = f"{target}'s catgegory wasn't changed."
                    )
            elif choice == "4":
                show_table(items)
            elif choice == "5":
                success = save_items(file_name, items)
                confirm_action(
                    success, 
                    success_message = f"Collection saved to {file_name} and backed up successfully.",
                    error_message = f"Save failed."
                )
            elif choice == "6":
                show_summary(items)
            elif choice == "7":
                category = prompt_nonempty("Enter category to filter: ").strip()
                results = filter_by_category(items, category)
                if results:
                    show_table(results)
                else:
                    print_error(f"No items found in '{category}'.")
            elif choice == "8":
                keyword = prompt_nonempty("Enter search keyword: ")
                success = search_by_keyword(items, keyword)
                confirm_action(
                    success,
                    success_message = f"Found {keyword} in items.",
                    error_message = f"Couldn't find {keyword} in items"
                )
            elif choice == "9":
                running = False
            else:
                print_error("Please choose input from menu above (1-9)")
    except (KeyboardInterrupt, EOFError):
        print(f"\n{Fore.CYAN}Interrupted, saving and exiting...")
    finally:
        print(Fore.CYAN + "Saving before exit...")
        ok = save_items(file_name, items)
        confirm_action(ok,
                       success_message = "Final save succeeded.",
                        error_message = "Final save FAILED")
        print("Have a greate day!")
    
    
def atomic_write(fname: Path, data: dict):
    _save_lock.acquire()
    try:
        temp = fname.with_suffix(".tmp")
        try:
            with temp.open("w") as f:
                json.dump(data, f, indent=2)
            temp.replace(fname)
        except PermissionError:
            print_error("Permission denied: cannot write data file.")
        except OSError as e:
            if e.errno == errno.ENOSPC:
                print_error("No space left on device: save failed")
            else:
                print_error(f"Filesystem error save: {e}")
    finally:
        _save_lock.release()
    
    
def autosave_loop(file_name, items):
    while True:
        time.sleep(config.AUTOSAVE_INTERVAL)
        if config.AUTOSAVE_ENABLED:
            save_items(file_name, items)

def show_table(items):
    if not items:
        print_error("No items yet.")
        return
    
    rows = [
        [item.get("id", ""), item["name"], item["category"], item["quantity"], item["time"]]
        for item in items
    ]
    headers = ["ID", "Name", "Category", "Quantity", "Time"]
    print(tabulate(rows, headers=headers, tablefmt="grid"))
        
def load_items(path: Path) -> list:
    try:
        with open(path) as f:
            return json.load(f)
    except FileNotFoundError:
        print_error("No file found at {path!r}. Starting with empty collection.")
        return []
    except json.JSONDecodeError:
        ts = datetime.now().strftime("%Y%m%dT%H%M%S")
        corrupt = path.with_name(f"{path.stem}_corrupt_{ts}{path.suffix}")
        path.replace(corrupt)
        print_error(f"Corrupt data detected; moved bad file to {corrupt.name}.")
        return []
        
def save_items(file_name, items):
    with _save_lock:
        data_dir = config.DATA_DIR
        base = data_dir / f"{file_name}.json"
    
        try:
            atomic_write(base, items)
            ts = datetime.now().strftime("%Y%m%dT%H%M%S")
            backup = data_dir / f"{file_name}_{ts}{config.BACKUP_SUFFIX}.json"
            atomic_write(backup, items)
        
            return rotate_backups(data_dir, file_name, keep=config.MAX_BACKUPS)
        except Exception as e:
            print_error(f"Save failed: {e}")
            return False
        
def edit_category(items):
    target = prompt_nonempty("Enter name of item to re-categorize: ")
    
    for item in items:
        if item['name'].lower() == target.lower():
            new_category = prompt_nonempty(f"Enter new category for {target}: ")
            item['category'] = new_category
            return True
    return False

def items_per_category(items):
    categories_count = {}
    for item in items:
        category = item['category']
        if category not in categories_count:
            categories_count[category] = 1
        else:
            categories_count[category] += 1
    if not categories_count:
        print_error("Items per category: none")
        return False
    else: 
        print_success("Items per category: ")
        sorted_categories = sorted(categories_count.items(), key=lambda x: x[1], reverse=True)
        for category, count in sorted_categories:
            print(f"    {category}: {count}")
        return True
            
def show_summary(items):
    print(f"Total items: {len(items)}")
    for category, quantity in get_category_distribution(items).items():
        print(f"    {category}: {quantity}")
    for period, quantity in get_time_distribution(items).items():
        print(f"    {period}: {quantity}")
    
def oldest_newest(items):
    if not items:
        print_error("No items in system to display.")
        return
    else:
        oldest_item = items[0]
        newest_item = items[0]
        dt_oldest = datetime.strptime(oldest_item["time"], "%Y-%m-%d %H:%M:%S")
        dt_newest = datetime.strptime(newest_item["time"], "%Y-%m-%d %H:%M:%S")
        
        for item in items[1:]:
            if datetime.strptime(item["time"], "%Y-%m-%d %H:%M:%S") > dt_newest:
                newest_item = item
                dt_newest = datetime.strptime(item["time"], "%Y-%m-%d %H:%M:%S")
            elif datetime.strptime(item["time"], "%Y-%m-%d %H:%M:%S") < dt_oldest:
                oldest_item = item
                dt_oldest = datetime.strptime(item["time"], "%Y-%m-%d %H:%M:%S")
        print(f"Oldest item: {oldest_item['name']}\nDate/Time: {oldest_item['time']}\n")
        print(f"Newest Item: {newest_item['name']}\nDate/Time: {newest_item['time']}\n")
        

        
def rotate_backups(data_dir: Path, prefix: str, keep: int):
    pattern = f"{prefix}_*{config.BACKUP_SUFFIX}.json"
    backups = sorted(
        data_dir.glob(pattern),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    success = True
    for old in backups[keep:]:
        try:
            old.unlink()
            print_success(f"Pruned old backup : {old}")
        except Exception as e:
            print_error(f"Could not delete {old}: {e}")
            success = False
    return success

def prompt_positive_int(prompt: str) -> int:
    while True:
        resp = input(Fore.YELLOW + prompt).strip()
        try:
            val = int(resp)
            if val > 0:
                return val
            else:
                print_error("Please enter a positive integer.")
        except ValueError:
            print_error("Not a number - try again")
            
def prompt_nonempty(prompt: str) -> str:
    while True:
        resp = input(Fore.YELLOW + prompt).strip()
        if resp:
            return resp
        print_error("Input cannot be blank.")

def print_header(text):
    print(Fore.CYAN + Style.BRIGHT + text)
    
def print_success(text):
    print(Fore.GREEN + text)
    
def print_error(text):
    print(Fore.RED + text)
    
def display_menu():
    menu = (
      Fore.CYAN + Style.BRIGHT +
      "\n=== Curation ===\n" + 
      Fore.YELLOW +
      "1) Add Item\n"
      "2) Remove Item\n"
      "3) Edit Category\n"
      "4) View Items\n"
      "5) Save Collection\n"
      "6) Summary\n"
      "7) Filter by Category\n"
      "8) Search by Keyword\n"
      "9) Quit\n" +
      Style.RESET_ALL
    )
    print(menu)
    
def confirm_action(ok: bool, success_message: str, error_message: str = None):
    if ok:
        print_success(success_message)
    else:
        print_error(error_message or success_message)

if __name__ == "__main__":
    main()